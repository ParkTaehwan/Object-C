//
//  LinkedList.m
//  LikedList
//
//  Created by MSW on 2015. 3. 11..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import "LinkedList.h"

@implementation LinkedList


- (instancetype)init
{
    self = [super init];
    if (self) {
        _linkedList = [[NSMutableArray alloc]initWithObjects:@"carrot",@"spinach", @"lettuce", @"cereal", @"milk", @"eggs", nil];
    }
    return self;
}

@end
