//
//  LinkedList.h
//  LikedList
//
//  Created by MSW on 2015. 3. 11..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LinkedList : NSObject

@property (strong,nonatomic) NSMutableArray * linkedList;
@property (strong, nonatomic) NSString * searchText;
@property (strong, nonatomic) NSString * addItemText;
@property (strong, nonatomic) NSString * removeItemText;


@end
