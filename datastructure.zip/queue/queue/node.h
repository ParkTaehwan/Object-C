//
//  node.h
//  queue
//
//  Created by MSW on 2015. 3. 12..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface node : NSObject

@property node *next;
//@property node *prev;
@property NSInteger *num;
-(id)initWith: (NSInteger *)num;

@end
