//
//  NSArray+Bsort.m
//  BubbleSort
//
//  Created by MSW on 2015. 3. 12..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import "NSArray+Bsort.h"

@implementation NSArray(Bsort)

-(NSArray*)sortedArrayWithBubbleSort {
    NSArray *myArray = self;
    NSMutableArray *sortArray = [myArray mutableCopy];
    BOOL swapped = TRUE;
    
    while (swapped) {
        swapped = FALSE; //after come back from going through the new array, if doesn't pass through the if loop where any of the previous objects are bigger than the next object, swapped will remain FALSE and stop running the while loop.
        for (int i = 1; i < [sortArray count]; i++) {
            if (sortArray[i-1] > sortArray[i]) {
                [sortArray exchangeObjectAtIndex:(i) withObjectAtIndex:(i-1)];
                swapped = TRUE;
            }
        }
    }
    
    NSArray *newArray = [sortArray copy];
    return newArray;
}

@end
