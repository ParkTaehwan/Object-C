//
//  stack.m
//  stack
//
//  Created by MSW on 2015. 3. 12..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import "stack.h"
#import "node.h"

@interface stack ()
@property node *top;
@end


@implementation stack

-(void)push: (NSInteger *) num
{
    if(!self.top)
    {
        node *newNode = [[node alloc]initWith:num];
        self.top = newNode;
        newNode.next = nil; //비어있는경우
    }
    else
    {
        
        node *newNode = [[node alloc]initWith:num];
        newNode.next = self.top;
        self.top = newNode; //비어있는게 아니면 값을 푸시
        
    }
}

-(NSInteger *)pop
{
    
    if(self.top)
    {
        node *topNode = self.top;
        self.top = self.top.next;
        return topNode.num;
    }
    return nil;
    
}

@end
