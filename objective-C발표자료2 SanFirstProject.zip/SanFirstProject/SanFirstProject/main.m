//
//  main.m
//  SanFirstProject
//
//  Created by MSW on 2015. 2. 4..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SanFirstClass.h"
#import "FirstChildClass.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        FirstChildClass *childClass = [[FirstChildClass alloc] init];
        
        [childClass setMyName:@"내 이름은 자식 클래스 입니다."]; //자식클래스인 FirstChildClass의 인스턴스에서
                                                          //SanFirstClass에 구현하였던 인스턴스 변수를 사용
        NSLog(@"%@", [childClass myName]);
        
        [FirstChildClass itIsClassMethod];                //itIsClassMethod는 자식클래스에 의해 오버라이드 되어있음
        
        [[childClass superclass] itIsClassMethod];        //오버라이드 되지 않은 메서드 호출은
                                                          //superclass의 메서드를 호출
        
        [childClass getMySecret];                         //getMySecret 메서드도 재정의 되어있음
        }
    
    return 0;
}

/*
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        //클래스 메서드는 초기화하지않고 메서드 호출 가능
        [SanFirstClass itIsClassMethod];
        
        //SanFirstClass의 인스턴스(객체)를 선언하고 초기화
        SanFirstClass *instance = [[SanFirstClass alloc] init];
        
        //인스턴의 인스턴스 변수인 myName을 세팅
        [instance setMyName:@"San"];
        
        //세팅된 myName을 name이라는 새로운 인스턴스에 넣어줌
        NSString *name = [instance myName];
        NSLog(@"내 이름은 %@.", name);
        
        //mySecret 세팅
        [instance setMySecret:@"이것은 일급비밀입니다!"];
        NSLog(@"내 비밀은 %@", [instance getMySecret]);
        
        //myFirstInt 세팅  [instance setMyFirstInt : 88]; 과 같음
        instance.myFirstInt = 88;
        NSLog(@"myFirstInt : %d", [instance myFirstInt]);
        
        //property 변수도 바꿀 수 있다
        instance.myName = @"my name";
        [instance setMyFirstInt : 77];
        
        NSLog(@"내 이름은 %@.", [instance myName]);
        NSLog(@"myFirstInt : %d", instance.myFirstInt);
    }
 */