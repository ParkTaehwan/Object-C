//
//  SanFirstClass.h
//  SanFirstProject
//
//  Created by MSW on 2015. 2. 4..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SanFirstClass : NSObject
{
    int         myFirstInt; //Integer variable
    NSString    *myName;    //NSString instance
    NSString    *mySecret;  //NSString instance
}

//Make getter, setter
@property (nonatomic, assign) int myFirstInt;   //assign property
@property (nonatomic, retain) NSString *myName; //retain property

//Instance Methods
- (void) myFirstMethod;
- (void) setMySecret:(NSString *)secret;
- (NSString *) getMySecret;

//Class Methods
+ (void) itIsClassMethod;

@end
