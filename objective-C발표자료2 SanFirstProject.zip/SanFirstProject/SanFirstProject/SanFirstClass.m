//
//  SanFirstClass.m
//  SanFirstProject
//
//  Created by MSW on 2015. 2. 4..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import "SanFirstClass.h"

@implementation SanFirstClass

@synthesize myFirstInt, myName;

//호출되면 로그를 남긴다
- (void) myFirstMethod{
    NSLog(@"이것은 인스턴스 메서드입니다.");
}

//mySecret 인스턴스를 설정해준다
- (void) setMySecret:(NSString *)secret{
    mySecret = [NSString stringWithString:secret];
}

//mySecret 인스턴스를 반환한다
- (NSString *) getMySecret{
    return mySecret;
}

//호출되면 로그를 남긴다
+ (void) itIsClassMethod{
    NSLog(@"이것은 클래스 메서드 입니다.");
}

@end
