//
//  FirstChildClass.m
//  SanFirstProject
//
//  Created by MSW on 2015. 2. 4..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import "FirstChildClass.h"

@implementation FirstChildClass

- (void) getMySecret{
    NSLog(@"getMySecret 메서드는 자식 클래스에 의해 재정의 되었습니다.");
}

+ (void) itIsClassMethod{
    NSLog(@"itIsClassMethod 메서드는 자식 클래스에 의해 재정의 되었습니다.");
}

@end
