//
//  FirstChildClass.h
//  SanFirstProject
//
//  Created by MSW on 2015. 2. 4..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import "SanFirstClass.h"

@interface FirstChildClass : SanFirstClass

//instance method
- (void) getMySecret;       //부모 클래스인 SanFirstClass의 getMySecret 이라는 인스턴스 클래스를
                            //재정의(오버라이딩) 할 수 있음
                            //메서드의 반환값이나 인자도 변경 가능

//class method
+ (void) itIsClassMethod;   //클래스 메서드도 재정의 가능
@end
